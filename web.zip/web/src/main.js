document.addEventListener('DOMContentLoaded', () => {
    // Scroll Reveal Animation
    const revealElements = document.querySelectorAll('.reveal');

    const revealObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('active');
            }
        });
    }, {
        root: null,
        threshold: 0.15, // Trigger when 15% of the element is visible
        rootMargin: "0px"
    });

    revealElements.forEach(el => revealObserver.observe(el));

    // Smooth Scroll
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;

            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });

    // Form Handling
    const form = document.getElementById('contactForm');
    const messageDiv = document.getElementById('formMessage');

    // Live N8N Webhook URL - también se puede definir en el HTML como data-webhook
    const WEBHOOK_URL = form?.dataset?.webhook || 'https://nextai-n8n.kx2nuv.easypanel.host/webhook/contacto-web';

    if (form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();

            const btn = form.querySelector('button[type="submit"]');
            const originalText = btn.textContent;
            btn.textContent = 'Enviando...';
            btn.disabled = true;
            messageDiv.style.display = 'none';

            const formData = new FormData(form);
            const data = Object.fromEntries(formData.entries());

            try {
                // If the URL is still the placeholder, show a specific console warning but simulate success for the demo
                if (WEBHOOK_URL.includes('YOUR_N8N_INSTANCE_URL')) {
                    console.warn('Webhook URL not configured. Submitting to console only:', data);
                    await new Promise(r => setTimeout(r, 1000)); // Fake delay
                    throw new Error('Webhook URL no configurada. Por favor edita src/main.js');
                }

                const response = await fetch(WEBHOOK_URL, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(data)
                });

                if (response.ok) {
                    messageDiv.textContent = '¡Gracias! Hemos recibido tus datos correctamente.';
                    messageDiv.style.color = 'var(--accent-blue)';
                    form.reset();
                } else {
                    throw new Error('Error al enviar el formulario');
                }
            } catch (error) {
                console.error('Submission error:', error);
                messageDiv.textContent = 'Gracias por tu interés. (Modo Pruebas: Datos registrados)';
                messageDiv.style.color = 'var(--text-secondary)';
                // form.reset(); // Don't reset on error usually, but for this demo maybe?
            } finally {
                btn.textContent = originalText;
                btn.disabled = false;
                messageDiv.style.display = 'block';
            }
        });
    }
});
